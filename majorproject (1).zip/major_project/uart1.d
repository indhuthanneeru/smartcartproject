uart1.o: ..\cpp\ARM_G7\MAJOR_PROJECT\uart1.c
uart1.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
uart1.o: ..\cpp\ARM_G7\MAJOR_PROJECT\uart1.h
uart1.o: ..\cpp\ARM_G7\MAJOR_PROJECT\lcd.h
uart1.o: ..\cpp\ARM_G7\MAJOR_PROJECT\delay.h
