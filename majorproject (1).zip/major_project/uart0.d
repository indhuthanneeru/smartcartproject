uart0.o: ..\cpp\ARM_G7\MAJOR_PROJECT\uart0.c
uart0.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
uart0.o: ..\cpp\ARM_G7\MAJOR_PROJECT\delay.h
uart0.o: ..\cpp\ARM_G7\MAJOR_PROJECT\uart0.h
uart0.o: C:\KeilARM\ARM\RV31\INC\string.h
